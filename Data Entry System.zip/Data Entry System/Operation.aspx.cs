﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Data;

namespace project.Data_Entry_System
{
    public partial class Operation : System.Web.UI.Page
    {
        //string strConnString = ConfigurationManager.ConnectionStrings["conString"].ConnectionString;
        SqlConnection con = new SqlConnection("database=himanshu;data source=DESKTOP-DPROL90\\SQLEXPRESS;user Id=sa;password=sasysadmin");
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadGrid();
                TxtUsername.Text = "Welcome" + "-" + Session["uname"].ToString();
            }
        }
        protected void LoadGrid()
        {
            //Grid.Visible = true;
            string query = "Select * from Test_Table where upper(name) like upper('%" + TbxFilter.Text + "%')";
            SqlCommand cmd = new SqlCommand(query, con);
            if (con.State != ConnectionState.Open)
            {
                con.Close();
                con.Open();
            }
            DataTable dt = new DataTable();
            SqlDataAdapter adt = new SqlDataAdapter(cmd);
            adt.Fill(dt);
            Grid.DataSource = dt;
            Grid.DataBind();
            

        }
        protected void Add_Records(object sender, EventArgs e)
        {
            msg.Text = "";
            TbxName.Text = "";
            TbxFname.Text = "";
            TbxAge.Text = "";
            Modal_Add.Show();
            //Grid.Visible = false;
        }
        protected void Submit_Records(object sender, EventArgs e)
        {
            string query = @"Insert into Test_Table(name,fname,age,Selection_id) values( @p1,@p2,@p3,(SELECT MAX(selection_id)+1
                             FROM Test_Table))";
            SqlCommand cmd = new SqlCommand(query, con);
            if (con.State != ConnectionState.Open)
            {
                con.Close();
                con.Open();
            }
            cmd.Parameters.AddWithValue("@p1", TbxName.Text);
            cmd.Parameters.AddWithValue("@p2", TbxFname.Text);
            cmd.Parameters.AddWithValue("@p3", TbxAge.Text);
            int result;
            result = cmd.ExecuteNonQuery();
            if (result > 0)
            {
                TbxName.Text = "";
                TbxFname.Text = "";
                TbxAge.Text = "";
                msg.Text = "Submition Successfully Done !! ";
            }
            else
            {
                msg.Text = " Submition Not Done !! ";
            }
            LoadGrid();
            Modal_Add.Show();
        }
        protected void Edit_Records(object sender, EventArgs e)
        {
            Emsg.Text = "";
            TbxNameE.Text = "";
            TbxFnameE.Text = "";
            TbxAgeE.Text = "";

            Button button = (Button)sender;
            GridViewRow row = (GridViewRow)button.NamingContainer;
            HiddenField slid = (HiddenField)row.FindControl("SID");

            if (con.State != ConnectionState.Open)
            {
                con.Close();
                con.Open();
            }
            string query = "Select * from Test_Table where selection_id='" + slid.Value + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter adt = new SqlDataAdapter(cmd);
            adt.Fill(dt);
            TbxNameE.Text = dt.Rows[0][0].ToString();
            TbxFnameE.Text = dt.Rows[0][1].ToString();
            TbxAgeE.Text = dt.Rows[0][2].ToString();
            Edit_id.Value = dt.Rows[0][3].ToString();
            Modal_Edit.Show();
            //Grid.Visible = false;
        }
        protected void Update_Records(object sender, EventArgs e)
        {
            string query = @"Update Test_Table set name=@p1,fname=@p2,age=@p3 where selection_id ='" + Edit_id.Value + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            if (con.State != ConnectionState.Open)
            {
                con.Close();
                con.Open();
            }
            cmd.Parameters.AddWithValue("@p1", TbxNameE.Text);
            cmd.Parameters.AddWithValue("@p2", TbxFnameE.Text);
            cmd.Parameters.AddWithValue("@p3", TbxAgeE.Text);
            int result;
            result = cmd.ExecuteNonQuery();
            if (result > 0)
            {
                Emsg.Text = "Updation Successfully Done !! ";
            }
            else
            {
                Emsg.Text = " Updation Not Done !! ";
            }
            LoadGrid();
            Modal_Edit.Show();
        }
        protected void Delete_Records(object sender, EventArgs e)
        {
            Dmsg.Text = "";
            TbxNameD.Text = "";
            TbxFnameD.Text = "";
            TbxAgeD.Text = "";
            Button button = (Button)sender;
            GridViewRow row = (GridViewRow)button.NamingContainer;
            HiddenField slid = (HiddenField)row.FindControl("SID");
            if (con.State != ConnectionState.Open)
            {
                con.Close();
                con.Open();
            }
            string query = "Select * from Test_Table where selection_id='" + slid.Value + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter adt = new SqlDataAdapter(cmd);
            adt.Fill(dt);
            TbxNameD.Text = dt.Rows[0][0].ToString();
            TbxFnameD.Text = dt.Rows[0][1].ToString();
            TbxAgeD.Text = dt.Rows[0][2].ToString();
            Delete_id.Value = dt.Rows[0][3].ToString();
            Modal_Delete.Show();
            //Grid.Visible = false;
        }
        protected void Finaly_Delete_Records(object sender, EventArgs e)
        {
            string query = @"Delete from Test_Table  where selection_id ='" + Delete_id.Value + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            if (con.State != ConnectionState.Open)
            {
                con.Close();
                con.Open();
            }
            int result;
            result = cmd.ExecuteNonQuery();
            if (result > 0)
            {
                Dmsg.Text = "Records Successfully Deleted !! ";
            }
            else
            {
                Dmsg.Text = "Records Not Deleted !! ";
            }
            LoadGrid();
            Modal_Delete.Show();
        }
        protected void Filter_click(object sender, EventArgs e)
        {
            BtnFilter.Visible = false;
            BtnClrFilter.Visible = true;
            LoadGrid();
        }
        protected void Clear_Filter_click(object sender, EventArgs e)
        {
            TbxFilter.Text = "";
            BtnFilter.Visible = true;
            BtnClrFilter.Visible = false;
            LoadGrid();
        }
        protected void ExportGridToExcel(object sender, EventArgs e)
        {
            Response.Clear();
            Response.Buffer = true;
            Response.ClearContent();
            Response.ClearHeaders();
            Response.Charset = "";
            string FileName = "Test" + DateTime.Now + ".xls";
            StringWriter strwritter = new StringWriter();
            HtmlTextWriter htmltextwrtter = new HtmlTextWriter(strwritter);
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = "application/vnd.ms-excel";
            Response.AddHeader("Content-Disposition", "attachment;filename=" + FileName);
            Grid.GridLines = GridLines.Both;
            Grid.HeaderStyle.Font.Bold = true;
            Grid.RenderControl(htmltextwrtter);
            Response.Write(strwritter.ToString());
            Response.End();
        }
        public override void VerifyRenderingInServerForm(Control control)
        {
            
        }
        
    }
}