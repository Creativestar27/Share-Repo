﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Data;

namespace project.Data_Entry_System
{
    public partial class SignUp : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("database=himanshu;data source=DESKTOP-DPROL90\\SQLEXPRESS;user Id=sa;password=sasysadmin");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Btnsubmit_Click(object sender, EventArgs e)
        {
            string query = @"Insert into loginTest(uname,mail,uid,psw) values( @p1,@p2,@p3,@p4)";
            SqlCommand cmd = new SqlCommand(query, con);
            if (con.State != ConnectionState.Open)
            {
                con.Close();
                con.Open();
            }
            if (TbxCpsw.Text == Tbxpsw.Text)
            {
                cmd.Parameters.AddWithValue("@p1", TbxName.Text);
                cmd.Parameters.AddWithValue("@p2", Tbxmail.Text);
                cmd.Parameters.AddWithValue("@p3", TbxUid.Text);
                cmd.Parameters.AddWithValue("@p4", TbxCpsw.Text);
                int result;
                result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    TbxName.Text = "";
                    Tbxmail.Text = "";
                    TbxUid.Text = "";
                    TbxCpsw.Text = "";
                    msg.Text = " Successfully Sign-Up ! ";
                    msg1.Text = "";
                }
                else
                {
                    msg.Text = " Sign-Up Not Done !! ";
                }
            }
            else
            {
                msg1.Text = "password not match ! ";
            }
           
           
        }
    }
}