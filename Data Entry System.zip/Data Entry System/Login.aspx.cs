﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Web;
using System.Data;

namespace project.Data_Entry_System
{
    public partial class Login : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection("database=himanshu;data source=DESKTOP-DPROL90\\SQLEXPRESS;user Id=sa;password=sasysadmin");
        protected void Page_Load(object sender, EventArgs e)
        {
            msg.Text = "";
        }

        protected void Btnlogin_Click(object sender, EventArgs e)
        {
            if (con.State != ConnectionState.Open)
            {
                con.Close();
                con.Open();
            }
            string query = "Select uid,psw,uname from logintest where uid='" + TbxId.Text + "' and psw ='" + Tbxpsw.Text + "'";
            SqlCommand cmd = new SqlCommand(query, con);
            DataTable dt = new DataTable();
            SqlDataAdapter adt = new SqlDataAdapter(cmd);
            adt.Fill(dt);
            int Rows = dt.Rows.Count;
            if(Rows>0)
            {
                Session["uname"] = dt.Rows[0][2].ToString();
                Response.Redirect("Operation.aspx");
            }
            else
            {
               
                msg.Text = "Wrong User Id or Password";
            }
        }

        protected void BtnForgotpsw_Click(object sender, EventArgs e)
        {

        }
        protected void forgot_click(object sender, EventArgs e)
        {
            loginSection.Visible = false;
            ForgotSection.Visible = true;

        }
    }
}